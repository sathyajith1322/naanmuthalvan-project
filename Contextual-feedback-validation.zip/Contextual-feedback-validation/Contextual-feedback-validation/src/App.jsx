import { useState } from 'react';
import './App.css';

function App() {
  const [feedback, setFeedback] = useState('');
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(false);
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!feedback.trim()) {
      alert('Please enter feedback text');
      return;
    }
    
    setLoading(true);
    
    try {
      const response = await fetch('http://localhost:5000/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ text: feedback }),
      });
      
      const data = await response.json();
      setAnalysis(data);
    } catch (error) {
      console.error('Error analyzing feedback:', error);
      alert('Error analyzing feedback. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  
  const getSentimentColor = (sentiment) => {
    switch(sentiment) {
      case 'positive': return 'text-green-600';
      case 'negative': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };
  
  const getSentimentEmoji = (sentiment) => {
    switch(sentiment) {
      case 'positive': return '😃';
      case 'negative': return '😞';
      default: return '😐';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center py-12 px-4">
      <header className="w-full max-w-2xl">
        <h1 className="text-3xl font-bold text-blue-700 text-center mb-2">
          Tech Hub
        </h1>
        <p className="text-center text-gray-600 mb-8">
          Enter your feedback about educational technology to get sentiment analysis
        </p>
      </header>
      
      <main className="w-full max-w-2xl bg-white rounded-lg shadow-lg p-6">
        <form onSubmit={handleSubmit} className="mb-6">
          <div className="mb-4">
            <label htmlFor="feedback" className="block text-gray-700 text-sm font-bold mb-2">
              Your Feedback:
            </label>
            <textarea
              id="feedback"
              className="w-full px-3 py-2 text-gray-700 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 min-h-32"
              placeholder="Share your thoughts about an educational technology tool, platform, or experience..."
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              required
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 disabled:opacity-50"
          >
            {loading ? 'Analyzing...' : 'Analyze Feedback'}
          </button>
        </form>
        
        {analysis && (
          <div className="bg-gray-50 rounded-lg p-6">
            <h2 className="text-lg font-bold text-gray-800 mb-4">Analysis Results</h2>
            
            <div className="mb-4">
              <div className={`text-xl font-bold mb-2 ${getSentimentColor(analysis.sentiment)}`}>
                {getSentimentEmoji(analysis.sentiment)} {analysis.sentiment.charAt(0).toUpperCase() + analysis.sentiment.slice(1)} Feedback
              </div>
              <div className="text-gray-700">
                <span className="font-medium">Confidence Score:</span> {(analysis.confidence * 100).toFixed(2)}%
              </div>
            </div>
            
            <div className="mb-4">
              <h3 className="font-bold text-gray-800 mb-2">Key Insights:</h3>
              <ul className="list-disc pl-5 text-gray-700">
                {analysis.insights.map((insight, index) => (
                  <li key={index}>{insight}</li>
                ))}
              </ul>
            </div>
            
            <div>
              <h3 className="font-bold text-gray-800 mb-2">Recommendations:</h3>
              <p className="text-gray-700">{analysis.recommendation}</p>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;